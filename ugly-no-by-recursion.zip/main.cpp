
#include <iostream>

using namespace std;

//remove all the multiple of the divisior x
int getDivisor(int n,int x){
    while(n%x==0){
        n = n/x;
    }
    return n;
}

//check if a given no is ugly or not
bool isUgly(int n){
    n = getDivisor(n,2);
    n = getDivisor(n,3);
    n = getDivisor(n,5);
     
    return (n==1?1:0);
}

//get nth ugly no
int getNthUglyNo(int n){
    int count = 1,i=2;
    while(count<n){
        if(isUgly(i++))
            count++;
    }
    return i-1;
}
int main()
{
    //code to get nth ugly no
    //ugly no is the no that has divided only by 1,2,3,5
    //first few ugly no are 1,2,3,4,5,6,8,9,10,12,15,16,18,20........
    cout<<getNthUglyNo(7)<<endl;
    cout<<getNthUglyNo(10)<<endl;
    cout<<getNthUglyNo(15)<<endl;
    cout<<getNthUglyNo(150)<<endl;
    return 0;
}
